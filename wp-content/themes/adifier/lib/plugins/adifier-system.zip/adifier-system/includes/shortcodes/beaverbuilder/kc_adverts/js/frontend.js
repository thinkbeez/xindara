jQuery(document).ready(function($){
	$(document).trigger('kc_advert-js-trigger');
});