<div class="keyword-wrap">
	<input type="text" class="form-control" name="keyword" placeholder="<?php esc_attr_e( 'Search for...', 'adifier' ) ?>">
</div>